#!/bin/bash

root='/usr/local'

mkdir "${root}/include"
mkdir "${root}/lib"

sudo mv bin/*  "${root}/bin/"
sudo mv include "${root}/include/python3.13"

sudo mv libpython3.13.a "${root}/lib/"
sudo mv python3.13 "${root}/lib/python3.13"